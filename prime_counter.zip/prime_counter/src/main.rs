//! Multi-threaded Prime Counter
//!
//! Usage:
//!   cargo run --release -- <limit> <threads>
//!       Counts the primes in the range [2, limit] using <threads> threads.
//!
//!   cargo run --release -- --file <path> <threads>
//!       Reads one integer per line from <path> and counts how many are prime.

use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader};
use std::process;
use std::sync::Arc;
use std::thread;
use std::time::Instant;

/// Returns true if `n` is prime (trial division by 6k ± 1).
fn is_prime(n: u64) -> bool {
    match n {
        0 | 1 => false,
        2 | 3 => true,
        _ if n % 2 == 0 || n % 3 == 0 => false,
        _ => {
            let mut i = 5;
            while i * i <= n {
                if n % i == 0 || n % (i + 2) == 0 {
                    return false;
                }
                i += 6;
            }
            true
        }
    }
}

/// Splits `len` items into `threads` contiguous chunks and returns
/// (start, end) index pairs, end excluded.
fn chunk_bounds(len: usize, threads: usize) -> Vec<(usize, usize)> {
    let base = len / threads;
    let extra = len % threads; // the first `extra` chunks get one more item
    let mut bounds = Vec::new();
    let mut start = 0;
    for i in 0..threads {
        let size = base + if i < extra { 1 } else { 0 };
        bounds.push((start, start + size));
        start += size;
    }
    bounds
}

/// Counts primes in [2, limit] by giving each thread its own sub-range.
fn count_range(limit: u64, threads: usize) -> u64 {
    if limit < 2 {
        return 0;
    }
    let len = (limit - 1) as usize; // how many numbers are in [2, limit]
    let mut handles = Vec::new();

    for (id, (s, e)) in chunk_bounds(len, threads).into_iter().enumerate() {
        let lo = 2 + s as u64;
        let hi = 2 + e as u64; // end excluded
        let handle = thread::spawn(move || {
            let count = (lo..hi).filter(|&n| is_prime(n)).count() as u64;
            if lo < hi {
                println!("  Thread {id}: range [{lo}, {}] -> {count} primes", hi - 1);
            } else {
                println!("  Thread {id}: no work assigned");
            }
            count
        });
        handles.push(handle);
    }

    handles
        .into_iter()
        .map(|h| h.join().expect("a worker thread panicked"))
        .sum()
}

/// Counts primes in a list of numbers shared between threads with Arc.
fn count_list(numbers: Vec<u64>, threads: usize) -> u64 {
    let numbers = Arc::new(numbers);
    let mut handles = Vec::new();

    for (id, (s, e)) in chunk_bounds(numbers.len(), threads).into_iter().enumerate() {
        let nums = Arc::clone(&numbers); // increase the reference count, no copy
        let handle = thread::spawn(move || {
            let count = nums[s..e].iter().filter(|&&n| is_prime(n)).count() as u64;
            println!("  Thread {id}: {} numbers -> {count} primes", e - s);
            count
        });
        handles.push(handle);
    }

    handles
        .into_iter()
        .map(|h| h.join().expect("a worker thread panicked"))
        .sum()
}

/// Reads one integer per line from a file, skipping blank lines.
fn read_numbers(path: &str) -> io::Result<Vec<u64>> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let mut numbers = Vec::new();

    for (line_no, line) in reader.lines().enumerate() {
        let line = line?;
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        match trimmed.parse::<u64>() {
            Ok(n) => numbers.push(n),
            Err(_) => eprintln!("Warning: skipping line {}: '{}'", line_no + 1, trimmed),
        }
    }
    Ok(numbers)
}

fn parse_threads(s: &str) -> usize {
    match s.parse::<usize>() {
        Ok(t) if t > 0 => t,
        _ => usage_and_exit("<threads> must be a positive integer"),
    }
}

fn usage_and_exit(msg: &str) -> ! {
    eprintln!("Error: {msg}");
    eprintln!("Usage:");
    eprintln!("  prime_counter <limit> <threads>");
    eprintln!("  prime_counter --file <path> <threads>");
    process::exit(1);
}

fn main() {
    let args: Vec<String> = env::args().collect();

    let start = Instant::now();
    let (total, threads) = match args.len() {
        3 => {
            let limit = match args[1].parse::<u64>() {
                Ok(n) => n,
                Err(_) => usage_and_exit("<limit> must be a non-negative integer"),
            };
            let threads = parse_threads(&args[2]);
            println!("Counting primes in [2, {limit}] with {threads} thread(s)...");
            (count_range(limit, threads), threads)
        }
        4 if args[1] == "--file" => {
            let threads = parse_threads(&args[3]);
            let numbers = match read_numbers(&args[2]) {
                Ok(v) => v,
                Err(e) => usage_and_exit(&format!("could not read '{}': {e}", args[2])),
            };
            println!(
                "Checking {} numbers from '{}' with {threads} thread(s)...",
                numbers.len(),
                args[2]
            );
            (count_list(numbers, threads), threads)
        }
        _ => usage_and_exit("wrong number of arguments"),
    };
    let elapsed = start.elapsed();

    println!("Total primes found: {total}");
    println!("Threads used: {threads}");
    println!("Time elapsed: {:.3} ms", elapsed.as_secs_f64() * 1000.0);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn small_primes() {
        let primes: Vec<u64> = (0..30).filter(|&n| is_prime(n)).collect();
        assert_eq!(primes, vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29]);
    }

    #[test]
    fn known_counts() {
        assert_eq!(count_range(100, 4), 25);
        assert_eq!(count_range(1_000_000, 8), 78_498);
        assert_eq!(count_range(1, 4), 0);
    }

    #[test]
    fn thread_count_does_not_change_result() {
        for t in 1..=16 {
            assert_eq!(count_range(10_000, t), 1_229);
        }
    }
}
